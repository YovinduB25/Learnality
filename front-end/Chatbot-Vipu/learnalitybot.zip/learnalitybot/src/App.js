import logo from './logo.svg';
import './App.css';
import Chat from './component/Chat';


function App() {
  return (
     <Chat/>
  );
}

export default App;
